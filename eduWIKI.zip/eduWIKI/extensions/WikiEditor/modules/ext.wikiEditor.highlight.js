/*
 * JavaScript for WikiEditor Highlighting
 */

$( document ).ready( function() {
	// Add highlight module
	$( '#wpTextbox1' ).wikiEditor( 'addModule', 'highlight' );
} );
