/*
 * JavaScript for WikiEditor
 */

$( document ).ready( function() {
	// Initialize wikiEditor
	$( '#wpTextbox1' ).wikiEditor();
} );
