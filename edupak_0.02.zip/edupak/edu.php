if ( !defined( 'MEDIAWIKI' ) ) {
exit;
}

$wgExtensionFunctions[] = 'eduWIKI';
$wgExtensionCredits['other'][] = array(
'path' => __FILE__,
'name' => 'eduWIKI',
'author' => array( 'Jeffw' ),
'url' => 'http://code.google.com/p/eduwiki/',
'version' => '0.01',
'descriptionmsg' => 'An open source for-education wiki modification of MediaWiki.',

include_once('/eduUserRights.php');
#include_once('/edu.i18n.php');
#include_once('/eduCodeStopper.php'); // Nah...