/** eduCodeStopper
* Stops code from flowing due to possible issues.
* Requires manual [de]activation.
*/

## Add a "#" to comment something.
## Comment "if" area and remaining stuff.
## Or comment edu.php's "include_once('/eduCodeStopper.php')".
## :)

if ( !defined( 'NOTMEDIAWIKISOFTWARENOREDUWIKI' ) ) die();