/** eduUserRights
* This file (supposedly) adds newer user rights -
* Branches into different pages, so be careful when editing.
* Using this branch format all of the students, teachers, and tech have one incorporated right.
*/

include_once('eduUserRightsStudent.php');
include_once('eduUserRightsTeacher.php');
include_once('eduUserRightsTech.php');
include_once('eduUserRightsBlocked.php');
#include_once('eduUserRightsWildcard.php'); // I do prefer wildcard... - Deprecated due to possible WikiCode[y]Conflicts...
#include_once('eduUserRightsAsterisk');
#include_once('eduUserRightsAllUsers.php');
#include_once('eduUserRightsUser.php'); // I deprecate it due to possible WikiCode[y]Conflicts...