/** eduUserRightsBlocked
* Revokes permissions of users
* instead of using the SpecialBlock interface.
*/

$wgAvailableRights[] = 'blocked';

$wgRevokePermissions['blocked']['edit']       = true;
$wgRevokePermissions['blocked']['writeapi']   = true;
$wgRevokePermissions['blocked']['createpage'] = true;
$wgRevokePermissions['blocked']['createtalk'] = true;
$wgRevokePermissions['blocked']['upload'] = true;