/** eduUserRightsStudent
* Students have severely limited actions...
* Never give a priveleged user Student... :P
*/

$wgAvailableRights[] = 'studentrights';

$wgRevokePermissions['student']['move']              = true;
$wgRevokePermissions['student']['move-subpages']     = true;
$wgRevokePermissions['student']['move-rootuserpages'] = true; // can move root userpages
//$wgRevokePermissions['student']['movefile']         = true;	// Disabled for now due to possible bugs and security concerns
$wgRevokePermissions['student']['upload']            = true;
$wgRevokePermissions['student']['reupload']          = true;
$wgRevokePermissions['student']['reupload-shared']   = true;
$wgRevokePermissions['student']['sendemail']         = true;

$wgGroupPermissions['student']['read']              = true;
$wgGroupPermissions['student']['edit']              = true;
$wgGroupPermissions['student']['createpage']        = true;
$wgGroupPermissions['student']['createtalk']        = true;
$wgGroupPermissions['student']['writeapi']          = true;
$wgGroupPermissions['student']['minoredit']         = true;
$wgGroupPermissions['student']['purge']             = true; // can use ?action=purge without clicking "ok"