/** eduUserRightsTeacher
* For the teachers...
* Like sysop, can't block. Let them block with the "blocked" usergroup.
*/

$wgAvailableRights[] = 'teacherrights';

// Most extra permission abilities go to this group
# $wgGroupPermissions['teacher']['block']            = true; // use "blocked" usergroup instead - not in use and replaced with "blocked" usergroup.
$wgGroupPermissions['teacher']['createaccount']    = true;
$wgGroupPermissions['teacher']['delete']           = true;
$wgGroupPermissions['teacher']['bigdelete']        = true; // can be separately configured for pages with > $wgDeleteRevisionsLimit revs
$wgGroupPermissions['teacher']['deletedhistory']   = true; // can view deleted history entries, but not see or restore the text
$wgGroupPermissions['teacher']['deletedtext']      = true; // can view deleted revision text
$wgGroupPermissions['teacher']['undelete']         = true;
$wgGroupPermissions['teacher']['editinterface']    = true;
$wgGroupPermissions['teacher']['editusercss']      = true;
$wgGroupPermissions['teacher']['edituserjs']       = true;
$wgGroupPermissions['teacher']['editusercssjs']    = true;
$wgGroupPermissions['teacher']['import']           = true;
$wgGroupPermissions['teacher']['importupload']     = true;
$wgGroupPermissions['teacher']['move']             = true;
$wgGroupPermissions['teacher']['move-subpages']    = true;
$wgGroupPermissions['teacher']['move-rootuserpages'] = true;
$wgGroupPermissions['teacher']['patrol']           = true;
$wgGroupPermissions['teacher']['autopatrol']       = true;
$wgGroupPermissions['teacher']['protect']          = true;
$wgGroupPermissions['teacher']['proxyunbannable']  = true;
$wgGroupPermissions['teacher']['rollback']         = true;
$wgGroupPermissions['teacher']['upload']           = true;
$wgGroupPermissions['teacher']['reupload']         = true;
$wgGroupPermissions['teacher']['reupload-shared']  = true;
$wgGroupPermissions['teacher']['unwatchedpages']   = true;
$wgGroupPermissions['teacher']['autoconfirmed']    = true;
#$wgGroupPermissions['teacher']['upload_by_url']    = true;
$wgGroupPermissions['teacher']['ipblock-exempt']   = true;
$wgGroupPermissions['teacher']['blockemail']       = true;
$wgGroupPermissions['teacher']['markbotedits']     = true;
$wgGroupPermissions['teacher']['apihighlimits']    = true;
$wgGroupPermissions['teacher']['browsearchive']    = true;
$wgGroupPermissions['teacher']['noratelimit']      = true;
$wgGroupPermissions['teacher']['movefile']         = true;
$wgGroupPermissions['teacher']['unblockself']      = true;
$wgGroupPermissions['teacher']['suppressredirect'] = true;
#$wgGroupPermissions['teacher']['mergehistory']     = true;
#$wgGroupPermissions['teacher']['trackback']        = true;
$wgGroupPermissions['teacher']['sendemail']       = true;
$wgGroupPermissions['teacher']['createaccount']   = true;
$wgAddGroups['teacher']    = array('student');
$wgRemoveGroups['teacher'] = array('student');