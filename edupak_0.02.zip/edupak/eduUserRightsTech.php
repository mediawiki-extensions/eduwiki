/** eduUserRightsTech
* UserRights for Techs
* Like Wikimedia Stewards
* or (for typical small wikis) all-powerful bureaucrats
*/

$wgAvailableRights[] = 'techrights';

$wgGroupPermissions['tech'] = $wgGroupPermissions['teacher'];
$wgGroupPermissions['tech']['deleterevision']   = true;
$wgGroupPermissions['tech']['hideuser']         = true;
$wgGroupPermissions['tech']['suppressrevision'] = true;
$wgGroupPermissions['tech']['suppressionlog']   = true;
$wgGroupPermissions['tech']['siteadmin']        = true;
$wgGroupPermissions['tech']['userrrights']      = true;
$wgGroupPermissions['tech']['noratelimit']      = true;
$wgGroupPermissions['tech']['mergehistory']     = true;
$wgGroupPermissions['tech']['trackback']        = true;